/*
 *  quadTreeDmap.h
 *  kdTree2Dsdh
 *
 *  Created by Anand Kumar on 1/14/11.
 *  Copyright 2011 University of South Florida, Tampa. All rights reserved.
 *
 */

#ifndef _QUADTREEDMAP_H_
#define _QUADTREEDMAP_H_

#define MATHLIB_STANDALONE  1

#include "sdhtypes.h"
#include "cell.h"


class QuadTreeDmap
{
public:
	Cell		*m_densityMap;
	CellList	*m_levelInfo;
	int		    m_nLevels;
	const Atom	*m_atomList;
	const long long	m_nAtoms;

	const float	m_resolution;
	const int       m_nChildren;
	double		m_xmin, m_xmax;
	double		m_ymin, m_ymax;

private:
	int    computeLevels(void);
	bool   populateCellInfo(Cell *, long long);
	void   connectActiveNodes(void);

public:
	QuadTreeDmap(const Atom *, const SDHSettings);
	~QuadTreeDmap();
	void   buildDensityMap();
	int    resolveDistance(Cell *, Cell *) const;
	int    resolveDistance(Cell *, Cell *,	int &, int &, double &, double &) const;
	void   printTree();
};


QuadTreeDmap :: QuadTreeDmap(const Atom *atomArray, const SDHSettings set) :
		m_atomList(atomArray), m_nAtoms(set.maxAtoms), m_resolution(set.sdhRes), m_nChildren(4)
{
	if( m_atomList == NULL ) printError("No atoms found in input");
	m_nLevels = 0;
	m_densityMap = NULL;
	m_levelInfo  = NULL;

    double z1, z2;
	if( !computeMinMax(m_atomList, m_nAtoms, m_xmin, m_xmax, m_ymin, m_ymax, z1, z2) )
		printError("Min and Max can't be computed");
}

QuadTreeDmap :: ~QuadTreeDmap()
{
	Cell *node, *tempNode;
	if( m_levelInfo  != NULL ) {
		for(int i = 0; i < m_nLevels; i++){
			node = m_levelInfo[i].data.rsibling;
			while(node != NULL) {
				tempNode = node;
				node = node->rsibling;
				delete tempNode;
			}
		}
		delete [] m_levelInfo;
	}
	m_atomList = NULL;
}

void QuadTreeDmap :: buildDensityMap()
{
    cerr << "Building Quad-tree\n";
	// Compute number of levels possible in the data set
	if( computeLevels() < 1 ) printError("Could not compute levels");

	// Create the root node
	m_densityMap = new Cell( NULL, m_nChildren, m_xmin, m_xmax, m_ymin, m_ymax );

	// Allocate space for level info maintenance and initialize to root
	m_levelInfo = new CellList [m_nLevels];
	(m_levelInfo[0].data).rsibling = m_densityMap;

	// Remember: You are building the next level from level i
	for(int i = 0; i < m_nLevels-1; i++) {
		Cell* thisCell = m_levelInfo[ i ].data.rsibling;	// First node in this level
		Cell* connectLevel = &( m_levelInfo[ i+1 ].data);	// First node in next level
		while( thisCell != NULL ) {
			// Get dimensions of current node
			double x_low  = thisCell->x_min;
			double x_high = thisCell->x_max;
			double y_low  = thisCell->y_min;
			double y_high = thisCell->y_max;
			// Compute span of the children cells
			double x_span = (x_high-x_low) / 2.0;
			double y_span = (y_high-y_low) / 2.0;

			// Create the children Cell nodes from the span data
			// Front NW node
			thisCell->child[0] = new Cell( thisCell, m_nChildren, x_low, x_low + x_span,  y_low + y_span, y_high );
			// Front NE node
			thisCell->child[1] = new Cell( thisCell, m_nChildren, x_low + x_span, x_high, y_low + y_span, y_high );
			// Front SW node
			thisCell->child[2] = new Cell( thisCell, m_nChildren, x_low, x_low + x_span,  y_low,   y_low+ y_span );
			// Front SE node
			thisCell->child[3] = new Cell( thisCell, m_nChildren, x_low + x_span, x_high, y_low,  y_low + y_span );

			// Connect the children in the next level
			connectLevel->rsibling = thisCell->child[0];
			for(int itr = 0; itr < m_nChildren-1; itr++) {
				thisCell->child[ itr ]->rsibling = thisCell->child[ itr+1 ];
			}
			connectLevel = thisCell->child[m_nChildren-1];

			// Move to next Cell node in the current level
			thisCell = thisCell->rsibling;
		}
	}

	// Add information to the density map tree by traversing it for every atom
	fprintf(stderr, "Levels = %d, resolution = %0.2f. Populating density map information\n",
			m_nLevels, m_resolution);
	for(long long index=0; index<m_nAtoms; index++){
		if( !populateCellInfo( m_densityMap, index ) ) {
			fprintf(stderr, "Atom %lld not be mapped to any node\n",index);
			fprintf(stderr, "Atom position: %0.4f, %0.4f\n", m_atomList[index].x_pos,
					m_atomList[index].y_pos);
			exit(0);
		}
	}

	// connect the active nodes in each level
	connectActiveNodes();
}


// Connect all the active nodes (nonzero atoms) in the same level
void QuadTreeDmap :: connectActiveNodes(void)
{
	for(int i = 0; i < m_nLevels; i++) {
		Cell *node1 = &(m_levelInfo[i].data);
		Cell *node2 = node1->rsibling;

		m_levelInfo[i].resolution = node2->getDiagonal();
		m_levelInfo[i].nActive = 0;
		long long atomCount = 0, cellCount = 0;

		while( node2 != NULL ) {
			cellCount++;
			if( node2->a_cnt > 0 ) {
				m_levelInfo[i].nActive ++;	// increment active node count
				atomCount += node2->a_cnt;
				while( node1 != node2 ) {
					node1->nextActive = node2;
					node1 = node1->rsibling;
				}
			}
			node2 = node2->rsibling;
		}

		fprintf(stderr,"Level %d, resolution = %0.2f, cells = %lld, Active Nodes = %lld, atoms = %lld\n",
				i, m_levelInfo[i].resolution, cellCount, m_levelInfo[i].nActive, atomCount);
	}
}


// Incorporate atom information in a Cell
bool QuadTreeDmap :: populateCellInfo(Cell *node, long long index)
{
	bool found   = false;
	if( node == NULL ) return found;

	double x_pos = m_atomList[ index ].x_pos;
	double y_pos = m_atomList[ index ].y_pos;
	/*
	 printf("%f, %f, %f, %f \n", node->x_min/1000.0, node->x_max/1000.0,
	 node->y_min/1000.0, node->y_max/1000.0);
	 */
	if( x_pos >= node->x_min && x_pos <= node->x_max &&
	   y_pos >= node->y_min && y_pos <= node->y_max ) {
		// Increment the count of atoms in this Cell
		node->a_cnt++;
		found = true;
		// Keep the atom in lower level of tree
		if( node->child[0] == NULL ) {
			(node->atomid).push_back( index );
		}
		// Update the children cells if the atom lies in their boundary
		for( int i=0; i<m_nChildren; i++ ){
			if( populateCellInfo( node->child[i], index ) )  break;
		}
	}
	return found;
}


// Compute the total number of levels required for the density map tree
int QuadTreeDmap :: computeLevels(void)
{
	double x_span = m_xmax;
	double y_span = m_ymax;
	long long atm_cnt = m_nAtoms;

	// count levles till diagonal of cube is less than the bucket width or resolution
	double diag = sqrt( SQR(x_span-m_xmin) + SQR(y_span-m_ymin) );
	while( diag > m_resolution && atm_cnt > CELL2D_QUD_ATOMS ) {
		m_nLevels++;
		x_span  = m_xmin + (x_span - m_xmin)/2.0;
		y_span  = m_ymin + (y_span - m_ymin)/2.0;
		diag    = sqrt( SQR(x_span-m_xmin) + SQR(y_span-m_ymin) );
		atm_cnt = atm_cnt >> 2;
	}

	// I think level should be one more than the resolution for better results
	while( atm_cnt > CELL2D_QUD_ATOMS ){
		m_nLevels++;
		atm_cnt = atm_cnt >> 2;
	}

	return m_nLevels;
}


int QuadTreeDmap :: resolveDistance(Cell *node1, Cell *node2) const
{
	int lo_ind, hi_ind;
	double lbound, ubound;
	lo_ind = hi_ind = -1;
	return resolveDistance(node1, node2, lo_ind, hi_ind, lbound, ubound);
}


/* Resolves the distances between two cells node1 and node2. Return +ve value if they resolve into single
 * bucket. Otherwise, the left (l_ind) and right (h_ind) bucket indices are populated. Also the exact
 * minimum (l_bound) and maximum (u_bound) distance between the cells are populated.
 */
int QuadTreeDmap :: resolveDistance(Cell *node1, Cell *node2, int &l_ind, int &h_ind,
								  double &l_bound, double &u_bound) const
{
    if( node1 == node2 ) {
        l_bound = 0;
        u_bound = node1->getDiagonal();
    } else {
        node1->cellDistance2D(node2, l_bound, u_bound);
    }

	l_ind = (int) (l_bound / m_resolution);
	h_ind = (int) (u_bound / m_resolution);

	if( l_ind < 0 || h_ind < 0 ) {
		fprintf(stderr, "Alert ! Index is negative\n");
		fprintf(stderr, "  x1_low = %0.2f, x1_high = %0.2f, y1_low = %0.2f, y1_high = %0.2f\n",
				node1->x_min, node1->x_max, node1->y_min, node1->y_max);
		fprintf(stderr, "  x2_low = %0.2f, x2_high = %0.2f, y2_low = %0.2f, y2_high = %0.2f\n",
				node2->x_min, node2->x_max, node2->y_min, node2->y_max);
	}
	// fprintf(stderr, "l_bound = %f, u_bound = %f, l_ind = %d, h_ind = %d\n", l_bound, u_bound, l_ind, h_ind);

	if(l_ind == h_ind) return l_ind;
	return (-1) * h_ind; // use the h_bound value even if the two cells are not resolvable.
}


#endif // _DENSITYMAP_H_
