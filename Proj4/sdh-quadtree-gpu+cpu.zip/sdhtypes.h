#ifndef _SDHTYPES_H_
#define _SDHTYPES_H_

#include <iostream>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include <limits.h>
#include <sys/time.h>


#define  INF                 999999999.0
#define  IGNORE              0.0
#define  RAND_POINTS         10000
#define  CELL3D_OCT_ATOMS    8
#define  CELL3D_KDT_ATOMS    8
#define  CELL2D_QUD_ATOMS    4
#define  CELL2D_KDT_ATOMS    4

#define	SQR(x)	((x)*(x))


using namespace std;

enum algoType  {BRUTE_FORCE=1, BASIC_SDH, APPROX_SDH, JUMPBINARY_SDH};
enum Heuristic {LEFT, EQUAL, PROPORTIONAL};
enum cutDirection {XCUT=1, YCUT, XYCUT, YZCUT, ZXCUT};


struct SDHSettings {
	int	       dimensions;
	long long  maxAtoms;
	float      sdhRes;
	int        tree;
	int        sdhAlgo;
	int        heuristic;
	int        startLevel;
	int        maxLevel;
	int	       dataPolicy;
	float	   blockSize;
	float	   dataZfactor;
};

struct Treenode{
	double x_min;
	double x_max;
	double y_min;
	double y_max;
	unsigned long long int a_cnt;
		
};			




typedef struct hist_entry{
	//float min;
	//	//float max;
	unsigned long long int d_cnt;   /* need a long long type as the count might be huge */
} bucket;


// An atom of the simulation
class Atom {
public:
	int id;
	int type;
	double x_pos;
	double y_pos;
	double z_pos;
	long long rank;
};


void printError(const char *message)
{
	fprintf(stderr, "\n%s\n", message);
	exit(-1);
}


/* Compute the running time given start time */
float report_running_time(struct timeval startTime)
{
	long sec_diff, usec_diff;
	//struct timezone Idunno;
	struct timeval endTime;

	gettimeofday(&endTime, NULL);
	sec_diff = endTime.tv_sec - startTime.tv_sec;
	usec_diff= endTime.tv_usec-startTime.tv_usec;
	if(usec_diff < 0) {
		sec_diff --;
		usec_diff += 1000000;
	}

	return (float)(sec_diff*1.0 + usec_diff/1000000.0);
}


// Obtaining the correct seed value for random generator
unsigned time_seed()
{
	time_t now = time ( 0 );
	unsigned char *p = (unsigned char *)&now;
	unsigned seed = 0;

	for (size_t i = 0; i < sizeof now; i++ )
		seed = seed * ( UCHAR_MAX + 2U ) + p[i];
	return seed;
}


// Some computation to get uniform distributed random number
float uniform_deviate ( float seed )
{
	return seed * ( 1.0 / ( RAND_MAX + 1.0 ) );
}


// Find the min and max boundries of the simulation space
bool computeMinMax(const Atom *atomList, const long long nAtoms, double &xlow, double &xhigh,
                    double &ylow, double &yhigh, double &zlow, double &zhigh)
{
	xlow = ylow = zlow = DBL_MAX;
	xhigh = yhigh = zhigh = FLT_MIN;
	for( int i = 0; i < nAtoms; i++ ) {
		if(atomList[i].x_pos < xlow)  xlow = floor( atomList[i].x_pos );
		if(atomList[i].y_pos < ylow)  ylow = floor( atomList[i].y_pos );
		if(atomList[i].z_pos < zlow)  zlow = floor( atomList[i].z_pos );
		if(atomList[i].x_pos > xhigh) xhigh = ceil( atomList[i].x_pos );
		if(atomList[i].y_pos > yhigh) yhigh = ceil( atomList[i].y_pos );
		if(atomList[i].z_pos > zhigh) zhigh = ceil( atomList[i].z_pos );
	}

	// Need a cube i.e., equal length sides
	float max_dimension = fmax( xhigh-xlow, fmax(yhigh-ylow, zhigh-zlow) );
	xhigh = xlow + max_dimension;
	yhigh = ylow + max_dimension;
    zhigh = ( zlow != zhigh) ? zlow + max_dimension : zhigh;

	// zhigh = (zlow == zhigh) ? zlow : (zlow + max_dimension);

	fprintf(stderr, "\nThe system boundary:\n  xmin = %0.2f, xmax = %0.2f,\n", xlow, xhigh);
	fprintf(stderr, "  ymin = %0.2f, ymax = %0.2f\n", ylow, yhigh);
	fprintf(stderr, "  zmin = %0.2f, zmax = %0.2f\n", zlow, zhigh);

	if( xhigh < xlow || yhigh < ylow || zhigh < zlow )
		return false;

	return true;
}


// Compute distance between pair of points in given list of atoms
inline float p2p_distance(const Atom *atomList, int id1, int id2)
{
        return sqrt (
            SQR( atomList[id1].x_pos - atomList[id2].x_pos ) +
            SQR( atomList[id1].y_pos - atomList[id2].y_pos ) +
            SQR( atomList[id1].z_pos - atomList[id2].z_pos )
        );
}


#endif // _SDHTYPES_H_
