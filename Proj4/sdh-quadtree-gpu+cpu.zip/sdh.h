#ifndef _SDH_H_
#define _SDH_H_

#include <unistd.h>
#include "sdhtypes.h"
#include "histogram.h"
//#include "octTreeDmap.h"
#include "quadTreeDmap.h"
//#include "kdTree2Ddmap.h"
//#include "kdTree3Ddmap.h"

#include <fstream>

FILE * drawTree;
//long long nrecursion;  //counts the number of recursions have been called
int intraNodes(0);

template<class DMTree>
class SDHdensityMap
{
public: // Public data members
	Histogram	  *m_histogram;
	const SDHSettings  m_param;    // All parameters of the SDH algorithm
	long long nDirectDistancesComputed;

private: // Private data members
	int		    m_maxSDHlevel;
	float		m_runTime;
	int         m_beginLevel;
	struct timezone m_Idunno;
	struct timeval  m_startTime, recursion_startTime, m_bruteForce;
	DMTree *m_Dmap;

public: // Public functions
	SDHdensityMap(const Atom*, const SDHSettings);
	~SDHdensityMap();
	void SDH_bruteForce();
	void SDH_densityMap(bool);
	void SDH_approxDensityMap();
	void SDH_jumpBinary();
	int  totalBuckets() { return m_histogram->size(); }
	void output_histogram(char *) const;
	void printStatistics(char *) const;
	void printTree() const;

private: // Private functions
	void   resolveCells(Cell *, Cell *, int);
	void   resolveCellsApprox(Cell *, Cell *, int);
        void   resolveJumpBinaryCells(Cell *, Cell *, Cell *, Cell *, int);
	void   computeDirectDistance(Cell *, Cell *);
	void   computeDirectDistance(Cell *, Cell *, Cell *, Cell *);
	void   printNodeOrder(Cell *) const;
};


// The constructor
template<class DMTree>
SDHdensityMap<DMTree> :: SDHdensityMap(const Atom* listofAtoms, const SDHSettings setting) : m_param(setting)
{
	m_Dmap = new DMTree(listofAtoms, setting);
	m_Dmap->buildDensityMap();

	int  nBuckets  = (int) (m_Dmap->m_levelInfo[0].data.rsibling)->getDiagonal() / m_param.sdhRes + 1;
	cerr << "\nBuckets = " << nBuckets << endl;

	// Create the histogram buckets
	m_histogram = new Histogram( nBuckets, m_param.sdhRes );
	m_maxSDHlevel = m_param.maxLevel;
	m_beginLevel  = 0;
	m_runTime = 0.0;
	nDirectDistancesComputed = 0;
}


// The destructor
template<class DMTree>
SDHdensityMap<DMTree> :: ~SDHdensityMap()
{
	delete m_Dmap;
	m_Dmap = NULL;
	delete m_histogram;
}


// Brute force method to compute SDH
template<class DMTree>
void SDHdensityMap<DMTree> :: SDH_bruteForce()
{
	int h_pos;
	float dist;
	cerr << "Brute force SDH method\n";
	gettimeofday(&m_startTime, &m_Idunno);
	for(long long i=0; i < m_param.maxAtoms; i++) {
		for(long long j = i+1; j < m_param.maxAtoms; j++){
			dist  = p2p_distance(m_Dmap->m_atomList, i, j);
			h_pos = (int) dist / m_param.sdhRes;
			m_histogram->add(h_pos, 1);
		}
	}
	m_runTime = report_running_time(m_startTime);
}


// Computing basic SDH using density map tree
template<class DMTree>
void SDHdensityMap<DMTree> :: SDH_densityMap(bool jumpBinary)
{
	int work_level = 0;
	// Go to the level with Cell diagonal less and equal to SDH resolution (bucket width)
	for( work_level=0; work_level < m_Dmap->m_nLevels; work_level++ ) {
		if( m_Dmap->m_levelInfo[work_level].resolution <= m_param.sdhRes ) break;
	}

	cerr << "Basic SDH method\n";
	if( work_level >= m_Dmap->m_nLevels ) --work_level;
	fprintf(stderr, "Tree level = %d, working at level = %d, resolution=%0.2f\n",
                    m_Dmap->m_nLevels, work_level, m_Dmap->m_levelInfo[work_level].resolution);

	m_beginLevel = work_level; // Just for statistics
	
	/*nrecursion= new long long [m_Dmap->m_nLevels];	
	for (int i=0; i<m_Dmap->m_nLevels; i++) nrecursion[i]=0;
	*/

	gettimeofday(&m_startTime, NULL); // Set the timer begin for the enitre algorithm computation

	double diag = (m_Dmap->m_levelInfo[ work_level ].data.nextActive)->getDiagonal();

	if( diag <= m_param.sdhRes ) {
		// Compute the number of intra-node distances and update the histogram
		for(Cell * node1= m_Dmap->m_levelInfo[work_level].data.nextActive; node1 != NULL; node1= node1->nextActive){
			m_histogram->add(0, (node1->a_cnt * (node1->a_cnt - 1)) / 2 );
			intraNodes++;
			(m_Dmap->m_levelInfo[work_level].nIntraNodeDist) += (node1->a_cnt * (node1->a_cnt - 1))/2;
		 }
		// Comptue the number of inter-node distances
        	for( Cell *node1 =  m_Dmap->m_levelInfo[ work_level ].data.nextActive; node1 != NULL; node1 = node1->nextActive ) {
			for( Cell *node2 = node1->nextActive; node2 != NULL; node2 = node2->nextActive ) {
               			if(jumpBinary) resolveJumpBinaryCells(node1, node1, node2, node2, work_level);
                		else resolveCells(node1, node2, work_level);
           		}
       		}
	}
	// the leaf level does not have resolvable resolution  
	else {
        	for( Cell *node1 = m_Dmap->m_levelInfo[ work_level ].data.nextActive; node1 != NULL; node1 = node1->nextActive ) {
            		computeDirectDistance(node1, node1);
            		for( Cell *node2 = node1->nextActive; node2 != NULL;node2 = node2->nextActive ) {
                		computeDirectDistance(node1, node2);
           		 }
       		 }
	}
	m_runTime = report_running_time(m_startTime);
	fprintf(stderr, "Intra nodes: %d\n",intraNodes);
}


template<class DMTree>
void SDHdensityMap<DMTree> :: resolveCells(Cell *node1, Cell *node2, int work_level)
{
  //  nrecursion++;
    (m_Dmap->m_levelInfo[work_level].nCellPairs)++;
	if( node1->a_cnt == 0 || node2->a_cnt == 0 ) {
		(m_Dmap->m_levelInfo[work_level].nPairsResolved)++;
		return;
	}

/* prior to check the nodes' coordinates, if number of atom in two nodes are not greater than 
the threshold or if the their product is  not greater than square of treshold, compute 
the direct distance*/
 
/*    if( work_level == (m_Dmap->m_nLevels-1) &&
       ! node1->checkMinCellPoints(node2, m_param.dimensions) ) {
        computeDirectDistance(node1, node2);
        return;
    }
*/
	int hist_index = m_Dmap->resolveDistance( node1, node2 );
	// the cells resolve
	if( hist_index >= 0 ) {
		m_histogram->add(hist_index, node1->a_cnt * node2->a_cnt);
		(m_Dmap->m_levelInfo[work_level].nPairsResolved)++;
		(m_Dmap->m_levelInfo[work_level].nDistResolved) += node1->a_cnt * node2->a_cnt;
	} else if( node1->child[0] == NULL ) {
		// We are at the leaf level
		// Calculate distance between every pair of atoms in the cells.
		computeDirectDistance( node1, node2 );
	} else {
		// Resolve the children of the current two nodes
		for( int i=0; i<m_Dmap->m_nChildren; i++){
			for(int j=0; j<m_Dmap->m_nChildren; j++){
				resolveCells( node1->child[i], node2->child[j], work_level+1);
			}
		}
	}
	return ;
}


template<class DMTree>
void SDHdensityMap<DMTree> :: computeDirectDistance(Cell *cell1, Cell *cell2)
{
    nDirectDistancesComputed += (cell1 == cell2) ?
                                ( cell1->a_cnt * ( cell2->a_cnt - 1 ) ) / 2 :
                                cell1->a_cnt * cell2->a_cnt;

    for(unsigned int itr1 = 0; itr1 < cell1->atomid.size(); itr1++ ) {
        for(unsigned int itr2 = (cell1 == cell2) ? itr1+1 : 0 ;
                         itr2 < cell2->atomid.size(); itr2++ ) {
				double distance = p2p_distance( m_Dmap->m_atomList,
                             cell1->atomid[itr1], cell2->atomid[itr2] );
				int hist_index = (int) distance / m_param.sdhRes;
				m_histogram->add(hist_index, 1);
        }
    }
}


// Computing APPROXIMATE SDH using density map tree and stopping at levels specified
// Stops after descending down for given number of levels
template<class DMTree>
void SDHdensityMap<DMTree> :: SDH_approxDensityMap()
{
	int work_level = 0;
	// Go to the level with cell diagonal equal to SDH resolution (bucket width)
	for( work_level=0; work_level < m_Dmap->m_nLevels; work_level++ ) {
		if( m_Dmap->m_levelInfo[ work_level ].resolution <= m_param.sdhRes ) break;
	}

	fprintf(stderr, "Approximate basic interleaved density map method\n");
	if( work_level >= m_Dmap->m_nLevels ) work_level = m_Dmap->m_nLevels-1;
	fprintf(stderr, "Tree level = %d, working at level = %d, resolution = %0.2f\n",
                    m_Dmap->m_nLevels, work_level, m_Dmap->m_levelInfo[work_level].resolution);

	// Determine the level to stop for approximating
	m_maxSDHlevel += work_level;
	if( m_maxSDHlevel >= m_Dmap->m_nLevels ) m_maxSDHlevel = m_Dmap->m_nLevels-1;

	gettimeofday(&m_startTime, &m_Idunno);
	// Now resolve every pair of cells

	Cell *node1, *node2;
	node1 = m_Dmap->m_levelInfo[ work_level ].data.nextActive;
	float diag = m_Dmap->m_levelInfo[ work_level ].resolution;

	gettimeofday(&m_startTime, &m_Idunno);
	while( node1 != NULL ) {
		if( diag > m_param.sdhRes ) {
			node2 = node1;
		} else {
			m_histogram->add(0, (node1->a_cnt * (node1->a_cnt - 1)) / 2 );
			node2 = node1->nextActive;
		}
		while( node2 != NULL ) {
			resolveCellsApprox(node1, node2, work_level);
			node2 = node2->nextActive;
		}
		node1 = node1->nextActive;
	}
	m_runTime = report_running_time(m_startTime);
}


template<class DMTree>
void SDHdensityMap<DMTree> :: resolveCellsApprox(Cell *node1, Cell *node2, int currentLevel)
{
	if( node1->a_cnt == 0 || node2->a_cnt == 0 )
		return;

	int lo_ind, hi_ind;
	double lbound, ubound;
	int hist_index = m_Dmap->resolveDistance( node1, node2, lo_ind, hi_ind, lbound, ubound );
    if(node1 != node2) (m_Dmap->m_levelInfo[currentLevel].nCellPairs)++;
	// the cells resolve
	if( hist_index >= 0 ) {
		m_histogram->add(hist_index, node1->a_cnt * node2->a_cnt);
		if(node1 != node2) (m_Dmap->m_levelInfo[currentLevel].nPairsResolved)++;
	} else if( node1->child[0] == NULL || currentLevel >= m_maxSDHlevel ) {
		m_histogram->splitDistances(node1->a_cnt * node2->a_cnt, lo_ind, hi_ind,
					    lbound, ubound, m_param.heuristic);
	} else {
		// Resolve the children of the current two nodes
		for( int i=0; i<m_Dmap->m_nChildren; i++){
			for(int j=0; j<m_Dmap->m_nChildren; j++){
				resolveCellsApprox( node1->child[i], node2->child[j], currentLevel+1 );
			}
		}
	}
	return ;
}





template<class DMTree>
void SDHdensityMap<DMTree> :: resolveJumpBinaryCells(Cell *firstLeft, Cell *firstRight,
                                                     Cell *secondLeft, Cell *secondRight, int work_level)
{
    int last = m_Dmap->m_nChildren-1;
    int hist_index;

    for( Cell *node1 = firstLeft; node1 != NULL; node1 = node1->rsibling ) {
        for( Cell *node2 = secondLeft; node2 != NULL; node2 = node2->rsibling ){

            if (node1->a_cnt == 0 || node2->a_cnt == 0) {
            }
            else if( work_level == (m_Dmap->m_nLevels-1) &&
               ! node1->checkMinCellPoints(node2, m_param.dimensions) ) {
                computeDirectDistance(node1, node2);
            } else {
                hist_index = m_Dmap->resolveDistance( node1, node2 );
                (m_Dmap->m_levelInfo[work_level].nCellPairs)++;

                if( hist_index >= 0 ) {
                    // the cells resolve
                    m_histogram->add(hist_index, node1->a_cnt * node2->a_cnt);
                    (m_Dmap->m_levelInfo[work_level].nPairsResolved)++;
                    (m_Dmap->m_levelInfo[work_level].nDistResolved) += node1->a_cnt * node2->a_cnt;
                } else if( node1->child[0] == NULL ) {
                    // We are at the leaf level
                    // Calculate distance between every pair of atoms in the cells.
                    computeDirectDistance( node1, node2 );
                } else if (node1->child[0]->child[0] == NULL) {
                    resolveJumpBinaryCells( node1->child[0], node1->child[last],
                                            node2->child[0], node2->child[last],
                                            work_level+1 );
                }else {
                    // Resolve the children of the current two nodes
                    resolveJumpBinaryCells( node1->child[0]->child[0], node1->child[last]->child[last],
                                            node2->child[0]->child[0], node2->child[last]->child[last],
                                            work_level+2 );
                }
            }
            if(node2 == secondRight) break;
        }
        if(node1 == firstRight) break;
    }

	return ;
}



template<class DMTree>
void SDHdensityMap<DMTree> :: printStatistics(char *fileName) const
{
    long long unResolved, distResolved, intraNodeDist,bruteForceDist;
    long long sum(0);
    float ratio = 0.0;
    FILE *fp = ( fileName != NULL ) ? fopen(fileName, "a+") : stderr;
    fprintf(fp, "SDH resolution = %0.3f  start level = %d", m_param.sdhRes, m_beginLevel);
    fprintf(fp, "  stop levels = %d", m_Dmap->m_nLevels-1);
    unResolved = distResolved = intraNodeDist = bruteForceDist = 0;

    for(int i=m_beginLevel; i < m_Dmap->m_nLevels; i++) {
        long long pairs = m_Dmap->m_levelInfo[i].nCellPairs;
        fprintf(fp, "\nLevel %2d%10.2f", i, m_Dmap->m_levelInfo[i].resolution);
        // fprintf(fp, "\tActive Cells   = %12lld", m_Dmap->m_levelInfo[i].nActive);
        fprintf(fp, "\tRecursions(Pairs) = %12lld", pairs);
        unResolved = pairs - m_Dmap->m_levelInfo[i].nPairsResolved;
        ratio = float(unResolved) / (pairs==0 ? 1 : pairs);
        fprintf(fp, "\t Resolved = %12lld \tUnresolved = %12lld (%0.3f%%)", pairs-unResolved, unResolved, ratio*100);
//	fprintf(fp, "\t recursions called: %lld",nrecursion[i]);		

        distResolved  += m_Dmap->m_levelInfo[i].nDistResolved;
        intraNodeDist += m_Dmap->m_levelInfo[i].nIntraNodeDist;
    }
    ratio=float(distResolved)/m_histogram->totalDistances();
    fprintf(fp, "\n\nInter-node distances resolved: \t%lld (%0.3f%%)\n", distResolved, ratio*100);
   
    ratio = float(intraNodeDist)/m_histogram->totalDistances();
    fprintf(fp, "Intra-node distances resolved (%d nodes): \t%lld (%0.3f%%)\n", intraNodes, intraNodeDist, ratio*100);
   
    bruteForceDist=m_histogram->totalDistances() - distResolved - intraNodeDist;
    ratio = float(bruteForceDist)/m_histogram->totalDistances();
    fprintf(fp, "The number of distances resolved by Brute-Force: \t%lld (%0.3f%%)\n", bruteForceDist, ratio*100);

    for(int ii=0; ii<m_Dmap->m_nLevels; ii++) sum += m_Dmap->m_levelInfo[ii].nCellPairs;
   
    fprintf(fp, "The total number of recursions have been called: \t%lld\n", sum);


// print the leaf level nodes   
//    FILE * leafNodes = fopen("leafNodes.txt","a+");
//    fprintf(leafNodes, "number of atoms in each leaf nodes:\n");
//    for (Cell *node =  m_Dmap->m_levelInfo[m_Dmap->m_nLevels-1].data.rsibling; node != NULL; node = node->rsibling){
//   	fprintf(leafNodes,"%lld\n", node->a_cnt);
//  	}
//    fclose(leafNodes);    
}



template<class DMTree>
void SDHdensityMap<DMTree> :: output_histogram(char* fileName) const
{
	if ( fileName != NULL ) {
		FILE *fpHist = fopen(fileName, "a+");
        fprintf(fpHist,"\n----------------------------------------------\n");
		fprintf(fpHist, "The time spent on SDH query: \t%0.3f(sec)\n", m_runTime);
		m_histogram->outputHistogram(fpHist);
		fclose(fpHist);
	}
	else {
		m_histogram->outputHistogram(NULL);
	}
}


// pre-order tree traversal
template<class DMTree>
void SDHdensityMap<DMTree> :: printTree() const
{
   // drawTree=fopen("treeStruct.txt","w+");
    printNodeOrder(m_Dmap->m_densityMap);
   // fclose(drawTree);
    
}

template<class DMTree>
void SDHdensityMap<DMTree> :: printNodeOrder(Cell *node) const
{
    if( node == NULL ) return;
    for(int i=0; i<m_Dmap->m_nChildren; i++)
        printNodeOrder(node->child[i]);
   // fprintf(drawTree, "%ld  ", node->cid);
}


#endif // _SDHINTERLEAVED_H_
