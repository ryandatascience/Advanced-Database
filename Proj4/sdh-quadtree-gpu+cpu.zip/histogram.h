#ifndef _HISTOGRAM_H_
#define _HISTOGRAM_H_

#include <string.h>
#include "sdhtypes.h"


class Histogram {
public:
	Histogram(int, float);
	~Histogram();
	long long bucket(int);
	void add(int, long long);
	void remove(int, long long);
	int  size() { return m_nBins; }
	long long totalDistances();
	void splitDistances(long long, int, int, int, int, int);
	void outputHistogram(FILE *);

private:
	int m_nBins;
	long long m_nDistances;
	long long *m_Bucket;
	const float m_bucketWidth;
};


Histogram :: Histogram(int nSize, float binSize) : m_bucketWidth(binSize)
{
	m_nBins = nSize;
	m_Bucket = new long long [m_nBins];
	memset(m_Bucket, 0, sizeof(long long)*m_nBins);
	m_nDistances = -1;
}

Histogram :: ~Histogram()
{
	delete [] m_Bucket;
	m_nDistances = -1;
}

long long Histogram :: bucket(int index)
{
	if( index < 0 || index >= m_nBins )
		printError("Bin number exceeds histogram size in bin()");
	return m_Bucket[index];
}

void Histogram :: add(int index, long long distances)
{
	if( index < 0 || index >= m_nBins )
		printError("Bin number exceeds histogram size in add()");
	m_Bucket[index] += distances;
}

void Histogram :: remove(int index, long long distances)
{
	if( index < 0 || index >= m_nBins )
		printError("Bin number exceeds histogram size in add()");
	m_Bucket[index] -= distances;
}

long long Histogram :: totalDistances()
{
	if( m_nDistances == -1 ) {
		m_nDistances = 0;
		for(int i=0; i<m_nBins; i++)
			m_nDistances += m_Bucket[i];
	}
	return m_nDistances;
}


// Distribute distances into set different buckets based on index limits
// A heuristic is used to split the distances among specified bucket indices
void Histogram :: splitDistances(long long dist_count, int lo_index, int up_index,
			int lbound, int ubound, int heuristic)
{
	long long dist_to_all, dist_remain;
	switch( heuristic ) {
		case LEFT: // All to lower index bucket (left most bucket)
			add(lo_index, dist_count);
			break;

		case EQUAL: // Equally into each bucket in the range
			dist_to_all = (long long) dist_count / (up_index - lo_index + 1);
			dist_remain = (long long) dist_count % (up_index - lo_index + 1);
			for(int k = lo_index; k <= up_index; k++ ) {
				add(k, dist_to_all);
			} // take care of odd number of distances
			if( dist_remain != 0 ){
				for(int k = lo_index; k < lo_index + abs(dist_remain); k++ )
					add( k, ( (dist_remain < 0) ? -1 : 1 ) );
			}
			break;

		case PROPORTIONAL: // Proportionally into each bucket in range
		{
			// Compute total distances that go into the LEFTmost partially overlapped bucket
			long long lhsCounts = (long long) dist_count * ((lo_index+1) * m_bucketWidth - lbound) /
			(ubound - lbound);
			add(lo_index, lhsCounts);
			// Compute total distances that go into the RIGHTmost partially overlapped bucket
			long long rhsCounts = (long long) dist_count * (ubound - up_index * m_bucketWidth) /
			(ubound - lbound);
			add(up_index, rhsCounts);

			// Distribute the remaining distances equally among rest of the buckets
			dist_count -= (lhsCounts + rhsCounts);
			if( up_index-lo_index == 1 ) {
				add(lo_index, dist_count);
			} else {
				dist_to_all = (long long) dist_count / (up_index-1 - lo_index - 1 + 1);
				dist_remain = (long long) dist_count % (up_index-1 - lo_index - 1 + 1);
				for(int k = lo_index+1; k <= up_index-1; k++ ) {
					add(k, dist_to_all);
				} // take care of odd number of distances
				if( dist_remain != 0 ){
					for(int k = lo_index; k < lo_index + abs(dist_remain); k++ )
						add( k, ( (dist_remain < 0) ? -1 : 1 ) );
				}
			}
			//	fprintf(stderr, "left = %lld, right = %lld, middle = %lld\n",
			//			lhsCounts, rhsCounts,dist_count);
		}

			break;
		default:
			printError("Invalid heuristic");
			break;
	}
}



/* print histogram into a file */
void Histogram :: outputHistogram(FILE *fpHist)
{
	if( fpHist != NULL ) {
		for(int i=0; i< m_nBins; i++)
  			fprintf(fpHist, "The number of distances fall into No.%d bucket: \t%15lld \n", i+1, m_Bucket[i]);
		fprintf(fpHist, "The total number of distances in the entire histogram: \t%lld\n\n", totalDistances());
	} else {
		for(int i=0; i< m_nBins; i++) {
			if(i%5 == 0)  printf("\n%04d: ", i);
  			printf("%15lld | ", m_Bucket[i]);
  		}
		printf("\n T:%lld \n", totalDistances());
 	}
}


#endif // _HISTOGRAM_H_
