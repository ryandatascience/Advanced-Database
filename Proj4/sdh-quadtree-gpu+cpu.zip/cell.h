#ifndef _CELL_H_
#define _CELL_H_

#include "sdhtypes.h"
// A cell of the density map
class Cell {
public:
	double x_min;
	double x_max;
	double y_min;
	double y_max;
	double z_min;
	double z_max;
	long long	a_cnt;
	long int cid;
	static long int cellCounter;

    const int m_nChildren;
	Cell **child;
	Cell *parent;
	Cell *rsibling;
	Cell *nextActive;
	vector <long long> atomid;

    Cell();
    Cell(Cell *, int, double, double, double, double, double, double);
    ~Cell();
	double getDiagonal(Cell *);
	inline void cellDistance2D(Cell *, double &, double &) const;
	inline void pointCellDistance2D(double, double, Cell *, double &, double &) const;
	inline void cellDistance3D(Cell *, double &, double &) const;
	inline void pointCellDistance3D(double, double, double, Cell *, double &, double &) const;
	inline bool checkMinCellPoints(Cell *, int);
	Cell* leftLeaf();
	Cell* rightLeaf();
	friend void swap(float &a, float &b);
};

long int Cell :: cellCounter = 0;

// Information about each level
class CellList {
public:
	Cell data;
	long long nActive;
	float resolution;
	long long nCellPairs;
	long long nPairsResolved;
	long long nDistResolved;
	long long nIntraNodeDist;

	CellList() {
	    nCellPairs = nPairsResolved = nDistResolved = nActive = nIntraNodeDist = 0;
	    resolution = 0.0;
	}
};

Cell :: Cell () : m_nChildren(0)
{
}

Cell :: Cell(Cell *dad, int nChildren, double x_low, double x_high,
	double y_low, double y_high, double z_low=0, double z_high=0 ) : m_nChildren(nChildren)
{
	x_min = x_low;
	x_max = x_high;
	y_min = y_low;
	y_max = y_high;
	z_min = z_low;
	z_max = z_high;
	a_cnt = 0;
	cid   = cellCounter++;

    child = new Cell* [m_nChildren];
	for(int i = 0; i < m_nChildren; i++){
        child[i] = NULL;
	}
	parent     = dad;
	rsibling   = NULL;
	nextActive = NULL;
	atomid.clear();
}

Cell :: ~Cell() {
    delete [] child;
    atomid.clear();
}

double Cell :: getDiagonal(Cell *node = NULL) {
    if(node == NULL)
           return sqrt( SQR(x_max-x_min) + SQR(y_max-y_min) + SQR(z_max-z_min) );
    else
        return sqrt( SQR(node->x_max-node->x_min) + SQR(node->y_max-node->y_min) +
                     SQR(node->z_max-node->z_min) );
}

// Check if the number of points are enough for given dimension
inline bool Cell :: checkMinCellPoints(Cell *node, int dimension)
{
    int avg_atoms;
    if( m_nChildren == 8 ) avg_atoms = CELL3D_OCT_ATOMS;
    else if( m_nChildren == 4 ) avg_atoms = CELL2D_QUD_ATOMS;
    else avg_atoms = (dimension == 3) ? CELL3D_KDT_ATOMS : CELL2D_KDT_ATOMS;

    switch (dimension){
        case 3: if(this->a_cnt >= avg_atoms &&
                   node->a_cnt >= avg_atoms) return true;
                else if(this->a_cnt * node->a_cnt >= 64) return true;
                break;
        case 2:
                if(this->a_cnt >= avg_atoms &&
                   node->a_cnt >= avg_atoms) return true;
                else if(this->a_cnt * node->a_cnt >= 16) return true;
                break;
        default: return true;
    }
    return false;
}


// Return leftmost leaf child node of the current node
Cell* Cell :: leftLeaf()
{
    Cell *tmpLeft = this;
    while(tmpLeft->child[0] != NULL)
        tmpLeft = tmpLeft->child[0];
    return tmpLeft;
}


// Return rightmost leaf child node of the current node
Cell* Cell :: rightLeaf()
{
    Cell *tmpRight = this;
    while(tmpRight->child[m_nChildren-1] != NULL)
        tmpRight = tmpRight->child[m_nChildren-1];
    return tmpRight;
}


inline void Cell :: cellDistance2D(Cell *B, double &finalMin, double &finalMax) const
{
    double minDist, maxDist;
    pointCellDistance2D(x_min, y_min, B, minDist, maxDist);
    finalMin = minDist;
    finalMax = maxDist;
    pointCellDistance2D(x_max, y_min, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance2D(x_min, y_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance2D(x_max, y_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
}


inline void Cell :: pointCellDistance2D(double x, double y, Cell *A, double &minDist, double &maxDist) const
{
    double dist = 0.0;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_min) );
    minDist = maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_min) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
}



inline void Cell :: cellDistance3D(Cell *B, double &finalMin, double &finalMax) const
{
    double minDist, maxDist;
    pointCellDistance3D(x_min, y_min, z_min, B, minDist, maxDist);
    finalMin = minDist;
    finalMax = maxDist;
    pointCellDistance3D(x_max, y_min, z_min, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_min, y_max, z_min, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_min, y_min, z_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_max, y_max, z_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_max, y_max, z_min, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_min, y_max, z_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
    pointCellDistance3D(x_max, y_min, z_max, B, minDist, maxDist);
    if( minDist < finalMin ) finalMin = minDist;
    if( maxDist > finalMax ) finalMax = maxDist;
}


// Return the parallel side if B is parallel with A
inline void Cell :: pointCellDistance3D(double x, double y, double z, Cell *A, double &minDist, double &maxDist) const
{
    double dist = 0.0;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_min) + SQR(z-A->z_min) );
    minDist = maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_min) + SQR(z-A->z_min) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_max) + SQR(z-A->z_min) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_min) + SQR(z-A->z_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_max) + SQR(z-A->z_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_max) + SQR(z-A->z_min) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_min) + SQR(y-A->y_max) + SQR(z-A->z_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
    dist = sqrt( SQR(x-A->x_max) + SQR(y-A->y_min) + SQR(z-A->z_max) );
    if( dist < minDist ) minDist = dist;
    if( dist > maxDist ) maxDist = dist;
}

void swap(float &a, float &b)
{
	float c = b;
	b = a;
	a = c;
}


#endif // _CELL_H_
